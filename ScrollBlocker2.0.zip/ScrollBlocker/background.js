// 1. Inizializzazione dello Stato Globale con le nuove feature 2.0
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({
    isScrollBlockerActive: false,
    blockedCount: 0,
    penaltyType: "close",
    fartType: "default",
    customAudioUrl: "",
    hardcoreMode: false,
    whitelist: "",
    scheduleEnabled: false,
    scheduleStart: "09:00",
    scheduleEnd: "18:00",
    // --- NUOVE FEATURE v2.0 ---
    focusStreak: 0,               // 2. Focus Streak (Giorni consecutivi)
    shameCoins: 0,                // 3. Sistema di valuta virtuale negativa
    customRedirectUrl: "",        // 4. Redirect personalizzabile dall'utente
    strictMode: false,            // 5. Impedisce la disattivazione delle opzioni se attive
    audioVolume: 1.0,             // 6. Controllo granulare del volume
    ghostMode: false,             // 7. Chiude il tab senza fare rumore (per l'ufficio)
    totalSecondsSaved: 0,         // 8. Stima del tempo risparmiato (30s a Short)
    soundDelay: 0,                // 9. Ritardo personalizzato per il trigger audio
    rickrollChance: 0,            // 10. % di probabilità di subire un Rickroll invece del fart
    insultNotification: false,    // 11. Notifiche desktop con insulti motivazionali
    zenQuotes: false,             // 12. Mostra una citazione stoica prima di chiudere
    blackoutMode: false,          // 13. Blocca l'INTERO YouTube, non solo gli Shorts
    maxDailyAttempts: 5,          // 14. Numero massimo di tentativi prima del "Blocco Totale"
    dailyAttemptsToday: 0,        // 15. Contatore tentativi giornalieri
    lastResetDate: new Date().toDateString(), // 16. Monitoraggio cambio giorno per reset tentativi
    emergencyUnblockPassword: "", // 17. Password di sblocco d'emergenza
    isCurrentlyLockedOut: false,  // 18. Stato di Hard Lockout temporaneo
    blurIntensity: 0,             // 19. Sfocatura progressiva prima del blocco
    soundPitch: 1.0,              // 20. Pitch/Velocità dell'audio modificabile
    autoMuteTab: true,            // 21. Silenzia istantaneamente il tab prima di killarlo
    weeklyGoal: 50,               // 22. Obiettivo settimanale di Shorts bloccati
    antiProcrastinationTimer: 0   // 23. Timer di sessione pomodoro integrato
  });

  // 24. Integrazione Menu Contestuale (Tasto destro per bloccare al volo un canale)
  chrome.contextMenus.create({
    id: "quickBlockChannel",
    title: "Add keyword to Scroll Blocker Whitelist/Blacklist",
    contexts: ["selection"]
  });
});

// Reset sessione all'avvio
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.set({ isScrollBlockerActive: false });
  chrome.storage.local.get(["lastResetDate", "maxDailyAttempts"], (res) => {
    const today = new Date().toDateString();
    if (res.lastResetDate !== today) {
      chrome.storage.local.set({ dailyAttemptsToday: 0, lastResetDate: today, isCurrentlyLockedOut: false });
    }
  });
  chrome.tabs.create({ url: "prompt.html" });
});

// Ascoltatore dei messaggi della versione 2.0
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "closePromptTab" && sender.tab) {
    chrome.tabs.remove(sender.tab.id);
  }
  
  if (request.action === "triggerFart" && sender.tab) {
    handleViolation(sender.tab);
  }
});

// Gestione della violazione (Il braccio violento della legge)
function handleViolation(tab) {
  chrome.storage.local.get([
    "blockedCount", "penaltyType", "customRedirectUrl", "shameCoins", 
    "totalSecondsSaved", "insultNotification", "dailyAttemptsToday", 
    "maxDailyAttempts", "rickrollChance", "ghostMode", "autoMuteTab"
  ], (res) => {
    
    // Controlla il Lockout Giornaliero
    let currentAttempts = (res.dailyAttemptsToday || 0) + 1;
    let lockedOut = currentAttempts >= res.maxDailyAttempts;
    
    chrome.storage.local.set({
      blockedCount: (res.blockedCount || 0) + 1,
      shameCoins: (res.shameCoins || 0) + 15, // Guadagni 15 Shame Coins per errore
      totalSecondsSaved: (res.totalSecondsSaved || 0) + 30, // Ogni Short evitato = 30 secondi di vita guadagnati
      dailyAttemptsToday: currentAttempts,
      isCurrentlyLockedOut: lockedOut
    });

    // 21. Auto-Mute Tab istantaneo
    if (res.autoMuteTab) {
      chrome.tabs.update(tab.id, { muted: true });
    }

    // 11. Notifiche desktop con insulti motivazionali
    if (res.insultNotification) {
      chrome.notifications.create({
        type: "basic",
        iconUrl: "icon128.png",
        title: "Dopamine Addict Detected!",
        message: `You just triggered the blocker. That's ${currentAttempts} times today. Get back to work.`
      });
    }

    // Esegui la punizione (Close o Redirect)
    if (res.penaltyType === "redirect") {
      const url = res.customRedirectUrl || "https://en.wikipedia.org/wiki/Special:Random";
      chrome.tabs.update(tab.id, { url: url });
    } else {
      chrome.tabs.remove(tab.id);
    }

    // Gestione dell'audio (Se non è attivo il Ghost Mode)
    if (!res.ghostMode) {
      // 10. Rickroll Chance roll
      const roll = Math.random() * 100;
      const isRickroll = roll < (res.rickrollChance || 0);
      
      chrome.storage.local.set({ currentTriggerType: isRickroll ? "rickroll" : "fart" });
      
      chrome.tabs.create({ url: "audio.html", active: false }, (audioTab) => {
        setTimeout(() => {
          chrome.tabs.remove(audioTab.id);
        }, 3500);
      });
    }
  });
}

// 24. Gestore del tasto destro per aggiungere elementi alla whitelist al volo
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "quickBlockChannel" && info.selectionText) {
    chrome.storage.local.get(["whitelist"], (res) => {
      const existing = res.whitelist ? res.whitelist + ", " : "";
      chrome.storage.local.set({ whitelist: existing + info.selectionText.trim() });
    });
  }
});