chrome.storage.local.get(["fartType", "customAudioUrl", "audioVolume", "currentTriggerType", "soundPitch"], (result) => {
  const player = document.getElementById('fartPlayer');
  
  // Imposta Pitch e Volume (Feature v2.0)
  player.volume = result.audioVolume !== undefined ? result.audioVolume : 1.0;
  
  if (result.currentTriggerType === "rickroll") {
    player.src = "https://ia801602.us.archive.org/11/items/Rick_Astley_Never_Gonna_Give_You_Up/Rick_Astley_Never_Gonna_Give_You_Up.mp3";
  } else if (result.fartType === "wet") {
    player.src = "fart2.mp3";
  } else if (result.fartType === "custom" && result.customAudioUrl) {
    player.src = result.customAudioUrl;
  } else {
    player.src = "fart.mp3";
  }

  player.addEventListener('loadedmetadata', () => {
    player.playbackRate = result.soundPitch || 1.0;
  });

  player.play().catch(e => console.log("Audio skipped or blocked. Everything is fine."));
});