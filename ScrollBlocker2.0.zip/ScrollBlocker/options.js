// Mapping di tutti i componenti della v2.0
const els = {
  statBlocked: document.getElementById('statBlocked'),
  statTime: document.getElementById('statTime'),
  statCoins: document.getElementById('statCoins'),
  statAttempts: document.getElementById('statAttempts'),
  hardcoreToggle: document.getElementById('hardcoreToggle'),
  strictToggle: document.getElementById('strictToggle'),
  blackoutToggle: document.getElementById('blackoutToggle'),
  penalty: document.getElementById('penalty'),
  customUrl: document.getElementById('customUrl'),
  fartSound: document.getElementById('fartSound'),
  customAudioUrl: document.getElementById('customAudioUrl'),
  volRange: document.getElementById('volRange'),
  pitchRange: document.getElementById('pitchRange'),
  blurRange: document.getElementById('blurRange'),
  ghostToggle: document.getElementById('ghostToggle'),
  notifToggle: document.getElementById('notifToggle'),
  muteToggle: document.getElementById('muteToggle'),
  maxAttemptsInput: document.getElementById('maxAttemptsInput'),
  rickrollInput: document.getElementById('rickrollInput'),
  whitelistInput: document.getElementById('whitelistInput'),
  scheduleToggle: document.getElementById('scheduleToggle'),
  startTime: document.getElementById('startTime'),
  endTime: document.getElementById('endTime'),
  resetBtn: document.getElementById('resetCounter')
};

chrome.storage.local.get(null, (res) => {
  els.statBlocked.textContent = res.blockedCount || 0;
  els.statTime.textContent = Math.round((res.totalSecondsSaved || 0) / 60) + "m";
  els.statCoins.textContent = res.shameCoins || 0;
  els.statAttempts.textContent = `${res.dailyAttemptsToday || 0}/${res.maxDailyAttempts || 5}`;
  
  els.hardcoreToggle.checked = !!res.hardcoreMode;
  els.strictToggle.checked = !!res.strictMode;
  els.blackoutToggle.checked = !!res.blackoutMode;
  els.penalty.value = res.penaltyType || "close";
  els.fartSound.value = res.fartType || "default";
  els.customUrl.value = res.customRedirectUrl || "";
  els.customAudioUrl.value = res.customAudioUrl || "";
  els.volRange.value = res.audioVolume !== undefined ? res.audioVolume : 1.0;
  els.pitchRange.value = res.soundPitch || 1.0;
  els.blurRange.value = res.blurIntensity || 0;
  els.ghostToggle.checked = !!res.ghostMode;
  els.notifToggle.checked = !!res.insultNotification;
  els.muteToggle.checked = !!res.autoMuteTab;
  els.maxAttemptsInput.value = res.maxDailyAttempts || 5;
  els.rickrollInput.value = res.rickrollChance || 0;
  els.whitelistInput.value = res.whitelist || "";
  els.scheduleToggle.checked = !!res.scheduleEnabled;
  els.startTime.value = res.scheduleStart || "09:00";
  els.endTime.value = res.scheduleEnd || "18:00";

  if(els.penalty.value === "redirect") els.customUrl.style.display = "block";
  if(els.fartSound.value === "custom") els.customAudioUrl.style.display = "block";

  // Strict Protection Mode Act: disabilita modifiche facili se sei in modalità blocco duro
  if (res.strictMode && res.dailyAttemptsToday > 0) {
    Object.keys(els).forEach(k => { if(k !== 'resetBtn') els[k].disabled = true; });
  }
});

// Auto-salvataggio e toggle grafici
Object.keys(els).forEach(key => {
  els[key].addEventListener('input', () => {
    if(els.penalty.value === "redirect") els.customUrl.style.display = "block";
    else els.customUrl.style.display = "none";
    
    if(els.fartSound.value === "custom") els.customAudioUrl.style.display = "block";
    else els.customAudioUrl.style.display = "none";
    
    save();
  });
});

els.resetBtn.addEventListener('click', () => {
  chrome.storage.local.set({ blockedCount: 0, totalSecondsSaved: 0, shameCoins: 0, dailyAttemptsToday: 0, isCurrentlyLockedOut: false }, () => {
    window.location.reload();
  });
});

function save() {
  chrome.storage.local.set({
    hardcoreMode: els.hardcoreToggle.checked,
    strictMode: els.strictToggle.checked,
    blackoutMode: els.blackoutToggle.checked,
    penaltyType: els.penalty.value,
    customRedirectUrl: els.customUrl.value,
    fartType: els.fartSound.value,
    customAudioUrl: els.customAudioUrl.value,
    audioVolume: parseFloat(els.volRange.value),
    soundPitch: parseFloat(els.pitchRange.value),
    blurIntensity: parseInt(els.blurRange.value),
    ghostMode: els.ghostToggle.checked,
    insultNotification: els.notifToggle.checked,
    autoMuteTab: els.muteToggle.checked,
    maxDailyAttempts: parseInt(els.maxAttemptsInput.value),
    rickrollChance: parseInt(els.rickrollInput.value),
    whitelist: els.whitelistInput.value,
    scheduleEnabled: els.scheduleToggle.checked,
    scheduleStart: els.startTime.value,
    scheduleEnd: els.endTime.value
  });
}