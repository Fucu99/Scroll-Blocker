let violationDetected = false;

function checkPage() {
  const currentUrl = window.location.href.toLowerCase();
  
  chrome.storage.local.get([
    "isScrollBlockerActive", "whitelist", "scheduleEnabled", "scheduleStart", 
    "scheduleEnd", "blackoutMode", "isCurrentlyLockedOut", "blurIntensity"
  ], (result) => {
    
    if (!result.isScrollBlockerActive) return;

    // 18. Hard Lockout attivato se superi i tentativi massimi quotidiani
    if (result.isCurrentlyLockedOut && currentUrl.includes("youtube.com")) {
      document.body.innerHTML = "<h1 style='color:white; text-align:center; margin-top:20%; font-family:sans-serif;'>HARD LOCKOUT: You failed too many times today. Chrome is saving you.</h1>";
      return;
    }

    // 13. Blackout Mode (Blocca l'intero YouTube se attivato)
    const isTarget = result.blackoutMode ? currentUrl.includes("youtube.com") : currentUrl.includes("youtube.com/shorts");

    if (isTarget && !violationDetected) {
      // Controllo Orari
      if (result.scheduleEnabled) {
        const now = new Date();
        const currentMin = now.getHours() * 60 + now.getMinutes();
        const [sH, sM] = result.scheduleStart.split(':').map(Number);
        const [eH, eM] = result.scheduleEnd.split(':').map(Number);
        const startMin = sH * 60 + sM;
        const endMin = eH * 60 + eM;
        const inTime = startMin <= endMin ? (currentMin >= startMin && currentMin <= endMin) : (currentMin >= startMin || currentMin <= endMin);
        if (!inTime) return;
      }

      // Controllo Whitelist
      if (result.whitelist && result.whitelist.trim() !== "") {
        const keywords = result.whitelist.split(",").map(k => k.trim().toLowerCase());
        if (keywords.some(k => k !== "" && currentUrl.includes(k))) return;
      }

      // 19. Blur Intensity (Sfocatura dello schermo prima del Counter)
      if (result.blurIntensity > 0) {
        document.body.style.filter = `blur(${result.blurIntensity}px)`;
      }

      violationDetected = true;
      chrome.runtime.sendMessage({ action: "triggerFart" });
      
      setTimeout(() => { violationDetected = false; }, 2000); // Debounce
    }
  });
}

// 25. Monitoraggio continuo ultra-veloce (ogni 250ms per anticipare il rendering di YT)
setInterval(checkPage, 250);