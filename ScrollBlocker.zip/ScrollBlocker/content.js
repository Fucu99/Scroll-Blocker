function isTimeInSchedule(startStr, endStr) {
  const now = new Date();
  const currentTime = now.getHours() * 60 + now.getMinutes();
  
  const [startH, startM] = startStr.split(':').map(Number);
  const [endH, endM] = endStr.split(':').map(Number);
  
  const startTime = startH * 60 + startM;
  const endTime = endH * 60 + endM;
  
  if (startTime <= endTime) {
    return currentTime >= startTime && currentTime <= endTime;
  } else {
    // Gestisce gli orari che superano la mezzanotte (es. dalle 22:00 alle 02:00)
    return currentTime >= startTime || currentTime <= endTime;
  }
}

setInterval(() => {
  if (window.location.href.includes("youtube.com/shorts")) {
    chrome.storage.local.get([
      "isScrollBlockerActive", 
      "whitelist", 
      "scheduleEnabled", 
      "scheduleStart", 
      "scheduleEnd"
    ], (result) => {
      
      // Controllo 1: L'estensione deve essere attiva nella sessione attuale
      if (!result.isScrollBlockerActive) return;

      // Controllo 2: Se lo Schedule è attivo, verifica se siamo nell'orario giusto
      if (result.scheduleEnabled && !isTimeInSchedule(result.scheduleStart, result.scheduleEnd)) {
        return; // Siamo fuori dall'orario di blocco, non fa nulla
      }

      // Controllo 3: Whitelist (Se l'URL contiene una parola chiave salvata, salvalo)
      if (result.whitelist && result.whitelist.trim() !== "") {
        const keywords = result.whitelist.split(",").map(k => k.trim().toLowerCase());
        const currentUrl = window.location.href.toLowerCase();
        
        // Se l'URL contiene una delle parole chiave, interrompi il blocco
        const isWhitelisted = keywords.some(keyword => keyword !== "" && currentUrl.includes(keyword));
        if (isWhitelisted) return;
      }

      // Se supera tutti i controlli, scatta la ghigliottina
      chrome.runtime.sendMessage({ action: "triggerFart" });
    });
  }
}, 400);