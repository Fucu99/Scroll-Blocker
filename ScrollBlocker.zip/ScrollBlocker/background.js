chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.set({ 
    isScrollBlockerActive: false,
    fartType: "default",
    customAudioUrl: "",
    penaltyType: "close",
    // Nuove impostazioni PRO
    blockedCount: 0,
    hardcoreMode: false,
    whitelist: "",
    scheduleEnabled: false,
    scheduleStart: "09:00",
    scheduleEnd: "18:00"
  });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.set({ isScrollBlockerActive: false });
  chrome.tabs.create({ url: "prompt.html" });
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "closePromptTab" && sender.tab) {
    chrome.tabs.remove(sender.tab.id);
  }
  
  if (request.action === "triggerFart" && sender.tab) {
    // Incrementa il contatore dei blocchi
    chrome.storage.local.get(["blockedCount", "penaltyType"], (result) => {
      const newCount = (result.blockedCount || 0) + 1;
      chrome.storage.local.set({ blockedCount: newCount });

      const tabId = sender.tab.id;
      if (result.penaltyType === "redirect") {
        chrome.tabs.update(tabId, { url: "https://en.wikipedia.org/wiki/Special:Random" });
      } else {
        chrome.tabs.remove(tabId);
      }

      chrome.tabs.create({ url: "audio.html", active: false }, (audioTab) => {
        setTimeout(() => {
          chrome.tabs.remove(audioTab.id);
        }, 3000);
      });
    });
  }
});