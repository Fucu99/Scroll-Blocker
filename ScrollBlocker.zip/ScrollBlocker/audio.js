chrome.storage.local.get(["fartType", "customAudioUrl"], (result) => {
  const player = document.getElementById('fartPlayer');
  
  if (result.fartType === "wet") {
    // Se hai un secondo file chiamato fart2.mp3 nella cartella
    player.src = "fart2.mp3"; 
  } else if (result.fartType === "custom" && result.customAudioUrl) {
    player.src = result.customAudioUrl;
  } else {
    player.src = "fart.mp3"; // Il tuo file originale
  }
  
  player.volume = 1.0;
  player.play().catch(e => console.log("Audio play blocked or failed", e));
});