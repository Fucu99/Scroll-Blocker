chrome.storage.local.get(["hardcoreMode"], (result) => {
  if (result.hardcoreMode) {
    const noBtn = document.getElementById('noBtn');
    noBtn.disabled = true;
    noBtn.style.opacity = "0.2";
    noBtn.style.cursor = "not-allowed";
    noBtn.textContent = "No (Locked)";
  }
});

document.getElementById('yesBtn').addEventListener('click', () => {
  chrome.storage.local.set({ isScrollBlockerActive: true }, () => {
    chrome.runtime.sendMessage({ action: "closePromptTab" });
  });
});

document.getElementById('noBtn').addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: "closePromptTab" });
});