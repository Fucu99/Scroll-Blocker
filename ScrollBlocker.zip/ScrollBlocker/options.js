// Elementi DOM
const statsCount = document.getElementById('statsCount');
const penaltySelect = document.getElementById('penalty');
const fartSelect = document.getElementById('fartSound');
const customUrlInput = document.getElementById('customUrl');
const hardcoreToggle = document.getElementById('hardcoreToggle');
const whitelistInput = document.getElementById('whitelistInput');
const scheduleToggle = document.getElementById('scheduleToggle');
const startTimeInput = document.getElementById('startTime');
const endTimeInput = document.getElementById('endTime');
const resetBtn = document.getElementById('resetCounter');

// Carica tutto da storage
chrome.storage.local.get([
  "blockedCount", "penaltyType", "fartType", "customAudioUrl", 
  "hardcoreMode", "whitelist", "scheduleEnabled", "scheduleStart", "scheduleEnd"
], (res) => {
  if (res.blockedCount !== undefined) statsCount.textContent = res.blockedCount;
  if (res.penaltyType) penaltySelect.value = res.penaltyType;
  if (res.fartType) {
    fartSelect.value = res.fartType;
    if (res.fartType === "custom") customUrlInput.style.display = "block";
  }
  if (res.customAudioUrl) customUrlInput.value = res.customAudioUrl;
  hardcoreToggle.checked = !!res.hardcoreMode;
  if (res.whitelist) whitelistInput.value = res.whitelist;
  scheduleToggle.checked = !!res.scheduleEnabled;
  if (res.scheduleStart) startTimeInput.value = res.scheduleStart;
  if (res.scheduleEnd) endTimeInput.value = res.scheduleEnd;
});

// Event Listeners per il salvataggio automatico
fartSelect.addEventListener('change', () => {
  customUrlInput.style.display = (fartSelect.value === 'custom') ? 'block' : 'none';
  saveSettings();
});

penaltySelect.addEventListener('change', saveSettings);
customUrlInput.addEventListener('input', saveSettings);
hardcoreToggle.addEventListener('change', saveSettings);
whitelistInput.addEventListener('input', saveSettings);
scheduleToggle.addEventListener('change', saveSettings);
startTimeInput.addEventListener('change', saveSettings);
endTimeInput.addEventListener('change', saveSettings);

resetBtn.addEventListener('click', () => {
  chrome.storage.local.set({ blockedCount: 0 }, () => {
    statsCount.textContent = "0";
  });
});

function saveSettings() {
  chrome.storage.local.set({
    penaltyType: penaltySelect.value,
    fartType: fartSelect.value,
    customAudioUrl: customUrlInput.value,
    hardcoreMode: hardcoreToggle.checked,
    whitelist: whitelistInput.value,
    scheduleEnabled: scheduleToggle.checked,
    scheduleStart: startTimeInput.value,
    scheduleEnd: endTimeInput.value
  });
}